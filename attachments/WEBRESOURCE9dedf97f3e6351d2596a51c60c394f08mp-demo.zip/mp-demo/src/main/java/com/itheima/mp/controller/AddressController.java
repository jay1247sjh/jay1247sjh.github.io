package com.itheima.mp.controller;


import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author 苏苏
 * @since 2024-08-18
 */
@RestController
@RequestMapping("/address")
public class AddressController {

}
