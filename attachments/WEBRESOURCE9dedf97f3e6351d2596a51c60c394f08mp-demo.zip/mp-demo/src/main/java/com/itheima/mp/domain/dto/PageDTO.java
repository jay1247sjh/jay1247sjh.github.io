package com.itheima.mp.domain.dto;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.collection.CollUtil;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.itheima.mp.domain.po.User;
import com.itheima.mp.domain.vo.UserVO;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Collections;
import java.util.List;
import java.util.function.Function;
import java.util.stream.Collectors;

@Data
@ApiModel(description = "分页结果")
public class PageDTO<T> {
    @ApiModelProperty("总条数")
    private Long total;

    @ApiModelProperty("总页数")
    private Long pages;

    @ApiModelProperty("集合")
    private List<T> list;

    public static <PO, VO> PageDTO<VO> of(Page<PO> p, Class<VO> clazz) {
        PageDTO<VO> objectPageDTO = new PageDTO<>();
        //总条数
        objectPageDTO.setTotal(p.getTotal());
        //总页数
        objectPageDTO.setPages(p.getPages());
        //当前页数据
        List<PO> records = p.getRecords();
        if (CollUtil.isEmpty(records)) {
            objectPageDTO.setList(Collections.emptyList());
            return objectPageDTO;
        }
        objectPageDTO.setList(BeanUtil.copyToList(records, clazz));
        return objectPageDTO;
    }

    public static <PO, VO> PageDTO<VO> of(Page<PO> p, Function<PO, VO> convertor) {
        PageDTO<VO> objectPageDTO = new PageDTO<>();
        //总条数
        objectPageDTO.setTotal(p.getTotal());
        //总页数
        objectPageDTO.setPages(p.getPages());
        //当前页数据
        List<PO> records = p.getRecords();
        if (CollUtil.isEmpty(records)) {
            objectPageDTO.setList(Collections.emptyList());
            return objectPageDTO;
        }
        //map传入convertor的参数是一个对象，类型是PO类型的，手动转换成VO类型
        objectPageDTO.setList(records.stream().map(convertor).collect(Collectors.toList()));
        return objectPageDTO;
    }
}
