package com.itheima.mp.enums;

import com.baomidou.mybatisplus.annotation.EnumValue;
import com.fasterxml.jackson.annotation.JsonValue;
import lombok.Getter;

@Getter
public enum UserStatus {
    NORMAL(1, "正常"),

    FROZEN(2, "冻结");

    @EnumValue      //加上注解，mp将其值写入数据库
    @JsonValue      //不加注解，返回值为变量名（比如NORMAL），加上了就返回value值（1）
    private final int value;

    private final String desc;

    UserStatus(int value, String desc) {
        this.value = value;
        this.desc = desc;
    }
}
