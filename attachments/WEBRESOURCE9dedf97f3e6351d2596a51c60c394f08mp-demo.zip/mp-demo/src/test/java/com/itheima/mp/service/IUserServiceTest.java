package com.itheima.mp.service;

import com.baomidou.mybatisplus.core.metadata.OrderItem;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.itheima.mp.domain.po.User;
import com.itheima.mp.domain.po.UserInfo;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
class IUserServiceTest {

    @Autowired
    private IUserService userService;

    @Test
    void testSaveUser() {
        User user = new User();
        //user.setId(5L);
        user.setUsername("Lilei");
        user.setPassword("123");
        user.setPhone("18688990011");
        user.setBalance(200);
        user.setInfo(UserInfo.of(24, "英文老师", "female"));
        user.setCreateTime(LocalDateTime.now());
        user.setUpdateTime(LocalDateTime.now());
        userService.save(user);
    }

    @Test
    void testQuery() {
        List<User> users = userService.listByIds(List.of(1L, 2L));
        users.forEach(System.out::println);
    }

    @Test
    void testSaveBatch() {
        List<User> list = new ArrayList<>();
        for (int i = 0; i < 100000; i++) {
            list.add(new User());
            if (i % 1000 == 0) {
                //每一千次发一次请求
                userService.saveBatch(list);
                list.clear();
            }
        }
    }

    @Test
    void testPageQuery() {
        int pageNo = 1, pageSize = 2;
        Page<User> page = Page.of(pageNo, pageSize);
        //排序条件
        page.addOrder(new OrderItem("balance", true))
                .addOrder(new OrderItem("id", true));
        Page<User> result = userService.page(page);
        long total = result.getTotal();     //获取总条数
        long pages = result.getPages();     //获取总页数
        List<User> records = result.getRecords();
        System.out.println("total=" + total + " pages=" + pages + ", records=" + records);
    }
}