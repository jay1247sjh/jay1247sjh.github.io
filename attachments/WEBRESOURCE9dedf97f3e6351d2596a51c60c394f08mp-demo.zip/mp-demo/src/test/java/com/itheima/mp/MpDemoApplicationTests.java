package com.itheima.mp;

import org.junit.jupiter.api.Test;

class MpDemoApplicationTests {

    @Test
    void contextLoads() {

    }

}
