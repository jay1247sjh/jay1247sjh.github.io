package com.example.springbootwebcase1.service;

import com.example.springbootwebcase1.pojo.Dept;
import org.springframework.stereotype.Service;

import java.util.List;

public interface DeptService {

    List<Dept> list();

    void delete(Integer id) throws Exception;

    void add(Dept dept);

    void update(Dept dept);

}
