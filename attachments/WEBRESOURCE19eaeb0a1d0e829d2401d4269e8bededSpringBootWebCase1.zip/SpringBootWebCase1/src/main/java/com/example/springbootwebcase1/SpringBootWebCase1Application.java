package com.example.springbootwebcase1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.ServletComponentScan;

@ServletComponentScan
@SpringBootApplication
public class SpringBootWebCase1Application {

    public static void main(String[] args) {
        SpringApplication.run(SpringBootWebCase1Application.class, args);
    }

}
