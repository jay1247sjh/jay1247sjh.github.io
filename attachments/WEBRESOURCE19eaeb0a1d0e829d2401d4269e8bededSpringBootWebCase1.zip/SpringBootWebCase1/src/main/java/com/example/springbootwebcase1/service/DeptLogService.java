package com.example.springbootwebcase1.service;


import com.example.springbootwebcase1.pojo.DeptLog;

public interface DeptLogService {

    void insert(DeptLog deptLog);
}
