package com.example.springbootwebcase1.exception;

import com.example.springbootwebcase1.pojo.Result;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class GlobalExceptionHandler {
    @ExceptionHandler(Exception.class)
    public Result error(Exception exception) {
        exception.printStackTrace();
        return Result.error("处理失败");
    }
}
