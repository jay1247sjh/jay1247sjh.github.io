package com.example.springbootwebcase1.aop;

import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;

import java.util.Arrays;

@Aspect
@Slf4j
@Component
public class MyAspect1 {
    //    @Pointcut("execution(* com.example.springbootwebcase1.service.impl.DeptServiceImpl.list())||" +
//            "execution(* com.example.springbootwebcase1.service.impl.DeptServiceImpl.delete(java.lang.Integer))")
    @Pointcut("@annotation(com.example.springbootwebcase1.aop.MyLog)")
    private void pt() {

    }

    @Before("pt()")
    public void before(JoinPoint joinPoint) {
        log.info("before...");
    }

    @Around("pt()")
    public Object around(ProceedingJoinPoint proceedingJoinPoint) throws Throwable {
        log.info("around...");
        //获取目标对象类名
        String name = proceedingJoinPoint.getTarget().getClass().getName();
        log.info(name);
        //获取目标方法的方法名
        String method = proceedingJoinPoint.getSignature().getName();
        log.info(method);
        //获取目标方法传入的参数
        Object[] args = proceedingJoinPoint.getArgs();
        log.info(Arrays.toString(args));
        //目标方法执行
        Object result = proceedingJoinPoint.proceed();
        log.info((String) result);
        return result;
    }


}
