package com.example.springbootwebcase1;

import com.example.springbootwebcase1.service.DeptService;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwt;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@SpringBootTest
class SpringBootWebCase1ApplicationTests {
    @Autowired
    private DeptService deptService;
//    @Test
//    public void testGenJwt() {
//        Map<String, Object> claims = new HashMap<>();
//        claims.put("id", 1);
//        claims.put("name", "tom");
//        String jwt = Jwts.builder()
//                .signWith(SignatureAlgorithm.HS256, "itheima")       //设置前面算法，"itheima"是密钥（长度要为4个或以上）
//                .setClaims(claims)                  //自定义内容
//                .setExpiration(new Date(System.currentTimeMillis() + 3600 * 1000))     //设置有效期为当前时间 + 1小时
//                .compact();//拿到字符串类型的返回值
//        System.out.println(jwt);
//    }
//
//    @Test
//    public void testParseJwt() {
//        Claims claims = Jwts.parser()
//                .setSigningKey("itheima")
//                .parseClaimsJws("eyJhbGciOiJIUzI1NiJ9.eyJuYW1lIjoidG9tIiwiaWQiOjEsImV4cCI6MTcwMDMwMjcxMX0.aFUV-aVm6kNvce4KEBGYXRRDQ6oGrgpcsKOjmEnQwKA")
//                .getBody();
//        System.out.println(claims);
//    }

    @Test
    public void testAopDelete() throws Exception {
        deptService.delete(10);
    }
}
