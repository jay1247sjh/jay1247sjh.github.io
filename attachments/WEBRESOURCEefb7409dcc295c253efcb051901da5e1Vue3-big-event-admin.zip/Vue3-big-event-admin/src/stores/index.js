import { createPinia } from 'pinia'
import piniaPluginPersistedstate from 'pinia-plugin-persistedstate'
const pinia = createPinia()
pinia.use(piniaPluginPersistedstate)

export default pinia

import { useUserStore } from './modules/user'
export { useUserStore }

export * from './modules/counter' // 将counter里所有按需导出按需导入后，并且再次导出出去
