export const checkPhone = phone => phone.length === 11
export const checkCode = code => code.length === 6